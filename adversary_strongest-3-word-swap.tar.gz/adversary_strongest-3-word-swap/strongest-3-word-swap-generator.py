import numpy as np
from os import listdir
from os.path import isfile, join
import re
import sys
from random import randint

num_words_per_message = 250

# define for string cleaning
strip_special_chars = re.compile("[^A-Za-z0-9 ]+")
def cleanSentences(string):
    string = string.lower().replace("<br />", " ")
    return re.sub(strip_special_chars, "", string.lower())

# define for index finding
def findIndex(search_list, begin, end, key):
    mid = int((end - begin + 1)/2) + begin
    if end == begin:
        if search_list[mid] == key:
            return mid
        else:
            return -1
    if end == begin + 1:
        if search_list[begin] == key:
            return begin
        if search_list[end] == key:
            return end
        else:
            return -1
    if search_list[mid] < key:
        return findIndex(search_list, mid, end, key)
    return findIndex(search_list, begin, mid, key)

#Positive Top
#edie
#antwone
#din
#gunga
#yokai

#Negative Top
#boll
#410
#uwe
#tashan
#hobgoblins
bayes_top_positive = ['edie', 'antwone', 'din', 'gunga', 'yokai']
bayes_top_negative = ['boll', '410', 'uwe', 'tashan', 'hobgoblins']

# read in trained model
nb_neg_weights = open("../naive_bayes/model_data/negative_weights.txt", "r")
nb_pos_weights = open("../naive_bayes/model_data/positive_weights.txt", "r")
nb_stats       = open("../naive_bayes/model_data/training_stats.txt", "r")
wordsList = []
positive_weights = []
negative_weights = []
for i in range (0, int(nb_stats.readline())):
    wordsList.append(nb_stats.readline().replace('\n', ''))
    positive_weights.append(float(nb_pos_weights.readline()))
    negative_weights.append(float(nb_neg_weights.readline()))
nb_stats.close()
nb_neg_weights.close()
nb_pos_weights.close()

# test on test data (not adversarial or adversarial)
positiveFiles = ['../stanford_test/pos/' + f for f in listdir('../stanford_test/pos') if isfile(join('../stanford_test/pos/', f))]
negativeFiles = ['../stanford_test/neg/' + f for f in listdir('../stanford_test/neg') if isfile(join('../stanford_test/neg/', f))]
del positiveFiles[:(len(positiveFiles)/2)]
del negativeFiles[:(len(negativeFiles)/2)]

for pf in positiveFiles:
    with open(pf, "r") as f:
        line = cleanSentences(f.readline()).split()
        for j in range(3):
            index = 0
            strength = 0
            i = 0
            for word in line:
                wl_index = findIndex(wordsList, 0, len(wordsList)-1, word)
                if i >= num_words_per_message:
                    break
                if not wl_index == -1:
                    if (positive_weights[wl_index]/negative_weights[wl_index]) > strength:
                        strength = (positive_weights[wl_index]/negative_weights[wl_index])
                        index = i
                i += 1
            line[index] = bayes_top_negative[randint(0, 4)]
        adv_name = "pos/" + pf.split('/')[-1]
        with open(adv_name, "w") as out:
            for wd in line:
                out.write(wd + " ")
for nf in negativeFiles:
    with open(nf, "r") as f:
        line = cleanSentences(f.readline()).split()
        for j in range(3):
            index = 0
            strength = 0
            i = 0
            for word in line:
                wl_index = findIndex(wordsList, 0, len(wordsList)-1, word)
                if i >= num_words_per_message:
                    break
                if not wl_index == -1:
                    if (negative_weights[wl_index]/positive_weights[wl_index]) > strength:
                        strength = (negative_weights[wl_index]/positive_weights[wl_index])
                        index = i
                i += 1
            line[index] = bayes_top_positive[randint(0, 4)]
        adv_name = "neg/" + nf.split('/')[-1]
        with open(adv_name, "w") as out:
            for wd in line:
                out.write(wd + " ")
